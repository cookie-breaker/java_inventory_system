-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 08, 2022 at 09:47 AM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `movie_login`
--

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `movie_ID` int(30) NOT NULL,
  `category` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`movie_ID`, `category`) VALUES
(1, 'thriller'),
(2, 'thriller'),
(3, 'thriller'),
(4, 'thriller'),
(5, 'thriller'),
(6, 'romance'),
(7, 'romance'),
(8, 'romance'),
(9, 'romance'),
(10, 'romance'),
(11, 'horror'),
(12, 'horror'),
(13, 'horror'),
(14, 'horror'),
(15, 'horror'),
(16, 'humor '),
(17, 'humor'),
(18, 'humor '),
(19, 'humor'),
(20, 'humor '),
(21, 'scifi'),
(21, 'scifi'),
(22, 'scifi'),
(23, 'scifi'),
(24, 'scifi'),
(25, 'scifi');

-- --------------------------------------------------------

--
-- Table structure for table `login_tbl`
--

CREATE TABLE `login_tbl` (
  `username` varchar(256) NOT NULL,
  `password` varchar(256) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `login_tbl`
--

INSERT INTO `login_tbl` (`username`, `password`) VALUES
('admin', 'xyz@123'),
('bobcat', '123'),
('check', '123'),
('check3', '123'),
('check4', '123'),
('check5', '12345'),
('check6', '123456'),
('example', '123456'),
('john doe', '123456'),
('omalshi', '123abc'),
('shaggy', '123'),
('test2', '123456');

-- --------------------------------------------------------

--
-- Table structure for table `movie_tbl`
--

CREATE TABLE `movie_tbl` (
  `movie_ID` int(50) NOT NULL,
  `movie_name` varchar(150) NOT NULL,
  `price` decimal(50,0) NOT NULL,
  `in_stock` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `movie_tbl`
--

INSERT INTO `movie_tbl` (`movie_ID`, `movie_name`, `price`, `in_stock`) VALUES
(1, 'The Invitation', '1500', 'yes'),
(2, 'The Black Phone', '2000', 'yes'),
(3, 'Beast', '1500', 'yes'),
(4, 'The Unholy', '1500', 'no'),
(5, 'Old', '2500', 'no'),
(6, 'Kabir Singh', '2500', 'yes'),
(7, 'Ek Villain Returns', '2500', 'yes'),
(8, 'Meet Cute', '1500', 'no'),
(9, 'Heropanti 2', '2500', 'yes'),
(10, 'The Lost City', '2500', 'yes'),
(11, 'The Silence', '2500', 'yes'),
(12, 'Nope', '1500', 'no'),
(13, 'it Chaper Two', '2500', 'yes'),
(14, 'Truth or Dare', '2500', 'no'),
(15, 'The Nun', '2500', 'yes'),
(16, 'The Man From Toronto', '2500', 'yes'),
(17, 'Yes Day', '2000', 'no'),
(18, 'Spider-Man: Into the Spider Verse', '3000', 'yes'),
(19, 'Student of the Year 2', '2500', 'yes'),
(20, 'Central Intelligence', '2500', 'yes'),
(21, 'Warriors Of Future', '2500', 'yes'),
(22, 'Spiderhead', '2500', 'yes'),
(23, 'Spider-Man: No Way Home', '3000', 'yes'),
(24, 'Sonic The Hedgehog 2 ', '2500', 'no'),
(25, 'Annihilation', '3000', 'no');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD KEY `movie_ID` (`movie_ID`);

--
-- Indexes for table `login_tbl`
--
ALTER TABLE `login_tbl`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `movie_tbl`
--
ALTER TABLE `movie_tbl`
  ADD PRIMARY KEY (`movie_ID`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `categories`
--
ALTER TABLE `categories`
  ADD CONSTRAINT `categories_ibfk_1` FOREIGN KEY (`movie_ID`) REFERENCES `movie_tbl` (`movie_ID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
